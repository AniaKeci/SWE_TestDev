<?php
include("database-configuration.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $id = $_POST['id'];
    $date = $_POST['date'];
    $hour = $_POST['hour'];
    $status = $_POST['status'];
    $service = $_POST['service'];
    $patient = $_POST['patient'];
    $staff = $_POST['staff'];
    $assistantStaff = $_POST['assistant_staff'];
    $student = $_POST['student'];
    $confirmation = date('Y-m-d H:i:s');

    // Creating the SQL query
    $query = "UPDATE Appointment 
              SET Appointment_Date = ?, Appointment_Hour = ?, Appointment_Status = ?, 
                  Appointment_Confirmation = ?, Service_ID = ?, Patient_ID = ?, 
                  Staff_ID = ?, Assistant_Staff_ID = ?, Student_ID = ?
              WHERE Appointment_ID = ?";

    // Preparing the statement
    $stmt = mysqli_prepare($connection, $query);

    // Binding parameters to the statement
    mysqli_stmt_bind_param($stmt, "ssssssssss", $date, $hour, $status, $confirmation, $service, $patient, $staff, $assistantStaff, $student, $id);

    // Executing and closing the statement
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header('Location: manage-appointments.php');
    exit;
}

// Retrieve services
$serviceQuery = "SELECT Service_ID, Service_Name FROM Service";
$serviceResult = mysqli_query($connection, $serviceQuery);

// Retrieve patients
$patientQuery = "SELECT Patient_ID, CONCAT(Patient_Name, ' ', Patient_Surname) AS Patient_FullName FROM Patient";
$patientResult = mysqli_query($connection, $patientQuery);

// Retrieve staff members
$staffQuery = "SELECT Staff_ID, CONCAT(Staff_Name, ' ', Staff_Surname) AS Staff_FullName FROM Staff";
$staffResult = mysqli_query($connection, $staffQuery);

// Retrieve assistant staff members
$assistantStaffQuery = "SELECT Staff_ID, CONCAT(Staff_Name, ' ', Staff_Surname) AS AssistantStaff_FullName FROM Staff";
$assistantStaffResult = mysqli_query($connection, $assistantStaffQuery);

// Retrieve students
$studentQuery = "SELECT Student_ID, CONCAT(Student_Name, ' ', Student_Surname) AS Student_FullName FROM Student";
$studentResult = mysqli_query($connection, $studentQuery);

// Retrieve appointment details based on the provided ID
$id = $_GET['id'];
$query = "SELECT * FROM Appointment WHERE Appointment_ID = ?";
$stmt = mysqli_prepare($connection, $query);
mysqli_stmt_bind_param($stmt, "s", $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$row = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/DENTAL_CLINIC/css/patient-signup.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <title>Dent-Assist | Edit Appointment</title>
    <link rel="icon" href="/DENTAL_CLINIC/images/logo-color.png" type="image/png">
</head>

<body>
    <section class="container">
        <header>Edit Appointment</header>

        <form method="post" class="form">
            <div class="column">
                <div class="input-box">
                    <label for="date">Date</label>
                    <input type="date" name="date" id="date" value="<?php echo $row['Appointment_Date']; ?>" required>
                </div>
                <div class="input-box">
                    <label for="hour">Hour</label>
                    <input type="time" name="hour" id="hour" value="<?php echo $row['Appointment_Hour']; ?>" required>
                </div>
            </div>

            <div class="column">
                <div class="input-box">
                    <label for="service">Service</label>
                    <select name="service" id="service" required>
                        <?php while ($serviceRow = mysqli_fetch_assoc($serviceResult)) {
                            $selected = ($serviceRow['Service_ID'] === $row['Service_ID']) ? 'selected' : '';
                            echo "<option value='" . $serviceRow['Service_ID'] . "' $selected>" . $serviceRow['Service_Name'] . "</option>";
                        } ?>
                    </select>
                </div>
            </div>

            <div class="column">
                <div class="input-box">
                    <label for="status">Status</label>
                    <select name="status" id="status" required>
                        <option value="confirmed" <?php echo ($row['Appointment_Status'] === 'confirmed') ? 'selected' : ''; ?>>Confirmed</option>
                        <option value="ongoing" <?php echo ($row['Appointment_Status'] === 'ongoing') ? 'selected' : ''; ?>>Ongoing</option>
                        <option value="completed" <?php echo ($row['Appointment_Status'] === 'completed') ? 'selected' : ''; ?>>Completed</option>
                    </select>
                </div>
            </div>

            <div class="column">
                <div class="input-box">
                    <label for="patient">Patient</label>
                    <select name="patient" id="patient" required>
                        <?php while ($patientRow = mysqli_fetch_assoc($patientResult)) {
                            $selected = ($patientRow['Patient_ID'] === $row['Patient_ID']) ? 'selected' : '';
                            echo "<option value='" . $patientRow['Patient_ID'] . "' $selected>" . $patientRow['Patient_FullName'] . "</option>";
                        } ?>
                    </select>
                </div>
            </div>

            <div class="column">
                <div class="input-box">
                    <label for="staff">Staff</label>
                    <select name="staff" id="staff" required>
                        <?php while ($staffRow = mysqli_fetch_assoc($staffResult)) {
                            $selected = ($staffRow['Staff_ID'] === $row['Staff_ID']) ? 'selected' : '';
                            echo "<option value='" . $staffRow['Staff_ID'] . "' $selected>" . $staffRow['Staff_FullName'] . "</option>";
                        } ?>
                    </select>
                </div>

                <div class="input-box">
                    <label for="assistant_staff">A. Staff</label>
                    <select name="assistant_staff" id="assistant_staff" required>
                        <?php while ($assistantStaffRow = mysqli_fetch_assoc($assistantStaffResult)) {
                            $selected = ($assistantStaffRow['Staff_ID'] === $row['Assistant_Staff_ID']) ? 'selected' : '';
                            echo "<option value='" . $assistantStaffRow['Staff_ID'] . "' $selected>" . $assistantStaffRow['AssistantStaff_FullName'] . "</option>";
                        } ?>
                    </select>
                </div>

                <div class="input-box">
                    <label for="student">Student</label>
                    <select name="student" id="student" required>
                        <?php while ($studentRow = mysqli_fetch_assoc($studentResult)) {
                            $selected = ($studentRow['Student_ID'] === $row['Student_ID']) ? 'selected' : '';
                            echo "<option value='" . $studentRow['Student_ID'] . "' $selected>" . $studentRow['Student_FullName'] . "</option>";
                        } ?>
                    </select>
                </div>
            </div>

            <input type="hidden" name="id" value="<?php echo $row['Appointment_ID']; ?>">

            <div class="button-container">
                <button type="submit" class="button">Update Appointment</button>
            </div>
        </form>
    </section>
</body>

</html>
