<?php
include("database-configuration.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $date = $_POST['date'];
    $hour = $_POST['hour'];
    $confirmation = date('Y-m-d H:i:s');
    $serviceid = $_POST['service'];
    $patientid = $_POST['patient'];

    $query = "INSERT INTO appointment (Appointment_Date, Appointment_Hour, Appointment_Confirmation, Service_ID, Patient_ID) VALUES (?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($connection, $query);

    mysqli_stmt_bind_param($stmt, "sssss", $date, $hour, $confirmation, $serviceid, $patientid);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header('Location: patient-view.php');
    exit;
}

?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/DENTAL_CLINIC/css/patient-signup.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <title>Dent-Assist | Book Appointment</title>
    <link rel="icon" href="/DENTAL_CLINIC/images/logo-color.png" type="image/png">
</head>

<body>
    <section class="container">
        <header>Book Appointment</header>
        <form method="post" class="form">
            <div class="column">
                <div class="input-box">
                    <label for="date">Date</label>
                    <input type="date" name="date" id="date" required>
                </div>
                <div class="input-box">
                    <label for="hour">Hour</label>
                    <input type="time" name="hour" id="hour" required>
                </div>
            </div>
            <div class="column">
                <div class="input-box">
                    <label for="service">Service</label>
                    <select name="service" id="service" required>
                        <?php
                        $query = "SELECT * FROM service";
                        $result = mysqli_query($connection, $query);

                        if (mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<option value='" . $row['Service_ID'] . "'>" . $row['Service_Name'] . "</option>";
                            }
                        }
                        ?>
                    </select>
                </div>
            </div>
            <div class="column">
                <div class="input-box">
                    <label for="patient">Patient</label>
                    <select name="patient" id="patient" required>
                        <?php
                        $query = "SELECT * FROM patient";
                        $result = mysqli_query($connection, $query);

                        if (mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<option value='" . $row['Patient_ID'] . "'>" . $row['Patient_Name'] . " " . $row['Patient_Surname'] . "</option>";
                            }
                        }
                        ?>
                    </select>
                </div>
            </div>
            </div>
            </div>
            <div class="button-div">
                <button type="submit" id="add" name="add" class="button">Book</button>
            </div>
            <div class="main-page">
                <a href="patient-view.php" class="main-page-link">Go back to the main page</a>
            </div>
        </form>
    </section>
</body>
</html>