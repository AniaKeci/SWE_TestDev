<?php
include("database-configuration.php");

// Check if the service ID is provided in the URL parameters
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Retrieve the service details from the database
    $query = "SELECT * FROM service WHERE Service_ID=?";
    $stmt = mysqli_prepare($connection, $query);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($result)) {
        $serviceName = $row['Service_Name'];
        $serviceFee = $row['Service_Fee'];
        $serviceDuration = $row['Service_Duration'];
        $departmentID = $row['Department_ID'];
    } else {
        // Redirect to the manage services page if the service is not found
        header('Location: manage-services.php');
        exit;
    }

    mysqli_stmt_close($stmt);
} else {
    // Redirect to the manage services page if the service ID is not provided
    header('Location: manage-services.php');
    exit;
}

// Retrieve the list of departments from the database
$query = "SELECT * FROM department";
$departmentResult = mysqli_query($connection, $query);

// Check if the form has been submitted for updating the service
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $serviceName = $_POST['service_name'];
    $serviceFee = $_POST['service_fee'];
    $serviceDuration = $_POST['service_duration'];
    $departmentID = $_POST['department_id'];

    // Update the service in the database
    $query = "UPDATE service SET Service_Name=?, Service_Fee=?, Service_Duration=?, Department_ID=? WHERE Service_ID=?";
    $stmt = mysqli_prepare($connection, $query);
    mysqli_stmt_bind_param($stmt, "sdisi", $serviceName, $serviceFee, $serviceDuration, $departmentID, $id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header('Location: manage-services.php');
    exit;
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/DENTAL_CLINIC/css/patient-signup.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <title>Dent-Assist | Edit Service</title>
    <link rel="icon" href="/DENTAL_CLINIC/images/logo-color.png" type="image/png">
</head>

<body>
    <section class="container">
        <header>Edit Service</header>
        <form method="POST" action="edit-service.php?id=<?php echo $id; ?>" class="form">
            <div class="column">
                <div class="input-box">
                    <label>Service Name:</label>
                    <input type="text" id="service_name" name="service_name" value="<?php echo $serviceName; ?>" required>
                </div>
            </div>
            <div class="column">
                <div class="input-box">
                    <label>Service Fee:</label>
                    <input type="number" id="service_fee" name="service_fee" value="<?php echo $serviceFee; ?>" required>
                </div>
            </div>
            <div class="column">
                <div class="input-box">
                    <label>Service Duration:</label>
                    <input type="text" id="service_duration" name="service_duration" value="<?php echo $serviceDuration; ?>" required>
                </div>
            </div>
            <div class="column">
                <div class="input-box">
                    <label>Department:</label>
                    <select name="department_id" id="department_id" required>
                        <option value="">Select Department</option>
                        <?php
                        while ($row = mysqli_fetch_assoc($departmentResult)) {
                            $selected = ($row['Department_ID'] == $departmentID) ? 'selected' : '';
                            echo "<option value='" . $row['Department_ID'] . "' $selected>" . $row['Department'] . "</option>";
                        }
                        ?>
                    </select>
                </div>
            </div>
            </div>

            <div class="button-div">
                <button type="submit" id="update" name="update" class="button">Update</button>
            </div>
        </form>
    </section>
</body>

</html>