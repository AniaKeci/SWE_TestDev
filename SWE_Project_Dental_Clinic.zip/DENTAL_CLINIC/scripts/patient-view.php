<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width,, initial-scale=1.0">
    <link rel="stylesheet" href="/DENTAL_CLINIC/css/admin-dashboard.css">
    <title>Dent-Assist | Patient View</title>
    <link rel="icon" href="/DENTAL_CLINIC/images/logo-color.png" type="image/png">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />

</head>

<body>
    <div class="container">
        <aside>
            <div class="top">
                <div class="logo">
                    <img src="/DENTAL_CLINIC/images/logo.png" alt="logo">
                </div>
                <div class="close" id="close-btn">
                    <span class="material-symbols-sharp">close</span>
                </div>
            </div>

            <div class="sidebar">
                <a href="patient-view.php" class="active">
                    <span class="material-symbols-sharp">dashboard</span>
                    <h3>Dashboard</h3>
                </a>
                <a href="book-appointment.php">
                    <span class="material-symbols-sharp">today</span>
                    <h3>Book Appointment</h3>
                </a>
                <a href="patient-xray.php">
                    <span class="material-symbols-sharp">medical_information</span>
                    <h3>Add X-Ray</h3>
                </a>
                <a href="view-services.php">
                    <span class="material-symbols-sharp">medical_services</span>
                    <h3>Services</h3>
                </a>
                <a href="landing-page.php">
                    <span class="material-symbols-sharp">logout</span>
                    <h3>Logout</h3>
                </a>
            </div>
        </aside>
        <main>
            <h1>Dashboard</h1>
            <div class="date" id="current-time"></div>

            <div class="insights">
                <div class="staff">
                    <span class="material-symbols-sharp">clinical_notes</span>
                    <div class="middle">
                        <div class="left">
                            <h3>Services</h3>
                            <?php
                            include("database-configuration.php");
                            $query = "SELECT * FROM service";
                            $result = mysqli_query($connection, $query);

                            // Get the total number of staff members
                            $totalservices = mysqli_num_rows($result);

                            echo "<h1>" . $totalservices . "</h1>"; ?>
                        </div>
                        <div class="progress">
                            <!-- <svg>
                                <circle cx='38' cy='38' r='36'></circle>
                            </svg> -->
                            <div class="number">
                                <!-- <p>Total</p> -->
                            </div>
                        </div>
                    </div>
                    <small class="text-muted">Total Number</small>
                </div>
            </div>
        </main>
    </div>
    <script>
    // Function to update the current time
    function updateCurrentTime() {
        var currentTime = new Date();
        var hours = currentTime.getHours();
        var minutes = currentTime.getMinutes();
        var seconds = currentTime.getSeconds();

        // Format the time as "hh:mm:ss"
        var formattedTime = hours + " : " + minutes + " : " + seconds;

        // Update the content of the div with the current time
        document.getElementById("current-time").textContent = formattedTime;
    }

    // Call the updateCurrentTime function initially
    updateCurrentTime();

    // Call the updateCurrentTime function every second (1000 milliseconds)
    setInterval(updateCurrentTime, 1000);
</script>
</body>

</html>