<?php
include("database-configuration.php");

// Check if the emergency contact ID is provided in the URL parameters
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Retrieve the emergency contact details from the database
    $query = "SELECT * FROM emergencycontact WHERE Contact_ID=?";
    $stmt = mysqli_prepare($connection, $query);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($result)) {
        $name = $row['Contact_Name'];
        $surname = $row['Contact_Surname'];
        $relation = $row['Contact_Relation'];
        $phone = $row['Contact_Phone_Number'];
        $email = $row['Contact_Email'];
        $patient = $row['Patient_ID'];
    } else {
        // Redirect to the manage emergency contacts page if the emergency contact is not found
        header('Location: manage-emergency-contacts.php');
        exit;
    }

    mysqli_stmt_close($stmt);
} else {
    // Redirect to the manage emergency contacts page if the emergency contact ID is not provided
    header('Location: manage-emergency-contacts.php');
    exit;
}

// Check if the form has been submitted for updating the emergency contact
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $relation = $_POST['relation'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $patient = $_POST['patient'];

    // Update the emergency contact in the database
    $query = "UPDATE emergencycontact SET Contact_Name=?, Contact_Surname=?, Contact_Relation=?, Contact_Phone_Number=?, Contact_Email=?, Patient_ID=? WHERE Contact_ID=?";
    $stmt = mysqli_prepare($connection, $query);
    mysqli_stmt_bind_param($stmt, "sssssii", $name, $surname, $relation, $phone, $email, $patient, $id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header('Location: manage-emergency-contacts.php');
    exit;
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/DENTAL_CLINIC/css/patient-signup.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <title>Dent-Assist | Edit Emergency Contact</title>
    <link rel="icon" href="/DENTAL_CLINIC/images/logo-color.png" type="image/png">
</head>

<body>
    <section class="container">
        <header>Edit Emergency Contact</header>
        <form method="POST" action="edit-emergency-contact.php?id=<?php echo $id; ?>" class="form">
            <div class="column">
                <div class="input-box">
                    <label>Name:</label>
                    <input type="text" id="name" name="name" value="<?php echo $name; ?>" required>
                </div>
                <div class="input-box">
                    <label>Surname:</label>
                    <input type="text" id="surname" name="surname" value="<?php echo $surname; ?>" required>
                </div>
            </div>

            <div class="column">
                <div class="input-box">
                    <label>Relation:</label>
                    <input type="text" id="relation" name="relation" value="<?php echo $relation; ?>" required>
                </div>
                <div class="input-box">
                    <label>Phone Number:</label>
                    <input type="text" id="phone" name="phone" value="<?php echo $phone; ?>" required>
                </div>
            </div>

            <div class="column">
                <div class="input-box">
                    <label>Email:</label>
                    <input type="email" id="email" name="email" value="<?php echo $email; ?>" required>
                </div>
                <div class="input-box">
                    <label>Patient Name</label>
                    <br><br>
                    <select id="patient" name="patient" required>
                        <?php
                        $query = "SELECT * FROM patient";
                        $result = mysqli_query($connection, $query);

                        if (mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<option value='" . $row['Patient_ID'] . "'>" . $row['Patient_Name'] . " " . $row['Patient_Surname'] . "</option>";
                            }
                        }
                        ?>
                    </select>
                </div>
            </div>

            <div class="button-div">
                <button type="submit" id="update" name="update" class="button">Update</button>
            </div>
        </form>
    </section>
</body>

</html>