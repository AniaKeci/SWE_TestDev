<?php
include("database-configuration.php");

// Check if the department ID is provided in the URL parameters
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Delete the department from the database
    $query = "DELETE FROM department WHERE Department_ID=?";
    $stmt = mysqli_prepare($connection, $query);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header('Location: manage-departments.php');
    exit;
} else {
    header('Location: manage-departments.php');
    exit;
}
?>