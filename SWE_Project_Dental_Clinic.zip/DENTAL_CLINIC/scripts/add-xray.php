<?php
include ("database-configuration.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST["add"])) {
    $type = $_POST["name"];

    if (!isset($_FILES["image"]) || $_FILES["image"]["error"] == 4) {
        // echo "Image does not exist.";
    } else {
        $fileName = $_FILES["image"]["name"];
        $fileSize = $_FILES["image"]["size"];
        $tmpName = $_FILES["image"]["tmp_name"];

        $validImageExtension = ['jpg', 'jpeg', 'png'];

        $imageExtension = explode('.', $fileName);
        $imageExtension = strtolower(end($imageExtension));

        if (!in_array($imageExtension, $validImageExtension)) {
            echo "Invalid Image Extension";
        } else if ($fileSize > 1000000) {
            // Check if the image size is too large
            echo "Image Size Is Too Large";
        } else {
            // Generate a unique name for the image
            $newImageName = uniqid();
            $newImageName .= '.' . $imageExtension;

            // Move the uploaded image to the desired location
            move_uploaded_file($tmpName, 'uploaded_images/' . $newImageName);

            // Insert the image details into the database
            $query = "INSERT INTO xrays (XRay_Type, XRay_File) VALUES (?, ?)";
            $stmt = mysqli_prepare($connection, $query);
            mysqli_stmt_bind_param($stmt, "ss", $type, $newImageName);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
            header('Location: manage-xrays.php');
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width,, initial-scale=1.0">
    <link rel="stylesheet" href="/DENTAL_CLINIC/css/patient-signup.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <title>Dent-Assist | Add X-Ray</title>
    <link rel="icon" href="/DENTAL_CLINIC/images/logo-color.png" type="image/png">
</head>

<body>
    <section class="container">
        <header>Add X-Ray</header>

        <form method="post" class="form" enctype="multipart/form-data">
            <div class="column">
                <div class="input-box">
                    <label>Type</label>
                    <input type="text" name="name" id="name" required>
                </div>
            </div>
            <br>
            <div class="column">
                <label>Image</label>
                <input type="file" name="image" id="image" accept=".jpg, .jpeg, .png" value=""> <br> <br>
            </div>

            <div class="button-div">
                <button type="submit" id="add" name="add" class="button">Add</button>
            </div>
    </section>
</body>

</html>