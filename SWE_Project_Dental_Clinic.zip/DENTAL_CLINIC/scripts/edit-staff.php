<?php
include("database-configuration.php");

// Check if the staff ID is provided in the URL parameters
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch the staff member's details from the database
    $query = "SELECT * FROM staff WHERE Staff_ID=?";
    $stmt = mysqli_prepare($connection, $query);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);

    // Check if the form has been submitted
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Retrieve form data
        $name = $_POST['name'];
        $surname = $_POST['surname'];
        $birthdate = $_POST['birthdate'];
        $address = $_POST['address'];
        $phone = $_POST['phone'];
        $email = $_POST['email'];
        $position = $_POST['position'];
        $education = $_POST['education'];
        $salary = $_POST['salary'];

        // Update the staff member's details in the database
        $query = "UPDATE staff SET Staff_Name=?, Staff_Surname=?, Staff_DateOfBirth=?, Staff_Address=?, Staff_PhoneNumber=?, Staff_Email=?, Staff_Position=?, Staff_Education=?, Staff_Salary=? WHERE Staff_ID=?";
        $stmt = mysqli_prepare($connection, $query);
        mysqli_stmt_bind_param($stmt, "ssssssssdi", $name, $surname, $birthdate, $address, $phone, $email, $position, $education, $salary, $id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        // Redirect to the manage staff page
        header('Location: manage-staff.php');
        exit;
    }
} else {
    // If no staff ID is provided, redirect to the manage staff page
    header('Location: manage-staff.php');
    exit;
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width,, initial-scale=1.0">
    <link rel="stylesheet" href="/DENTAL_CLINIC/css/patient-signup.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <title>Dent-Assist | Edit Staff</title>
    <link rel="icon" href="/DENTAL_CLINIC/images/logo-color.png" type="image/png">
</head>

<body>
    <section class="container">
        <header>Edit Staff Member</header>

        <?php
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch the staff member's details from the database
    $query = "SELECT * FROM staff WHERE Staff_ID=?";
    $stmt = mysqli_prepare($connection, $query);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);

    if ($row) {
        $name = $row["Staff_Name"];
        $surname = $row["Staff_Surname"];
        $birthdate = $row["Staff_DateOfBirth"];
        $address = $row["Staff_Address"];
        $phone = $row["Staff_PhoneNumber"];
        $email = $row["Staff_Email"];
        $position = $row["Staff_Position"];
        $education = $row["Staff_Education"];
        $salary = $row["Staff_Salary"];
    } else {
        echo "Staff member not found.";
        exit();
    }

    mysqli_stmt_close($stmt);
} else {
    echo "Staff ID not provided.";
    exit();
}
?>
        <form method="post" class="form">
        <div class="column">
            <div class="input-box">
                <label>Name</label>
                <input type="text" name="name" id="name" value="<?php echo $name; ?>" required>
            </div>
            <div class="input-box">
                <label>Surname</label>
                <input type="text" name="surname" id="surname" value="<?php echo $surname; ?>" required>
            </div>
        </div>

            <div class="column">
                <div class="input-box">
                    <label>Birthdate</label>
                    <input type="date" name="birthdate" id="birthdate" value="<?php echo $birthdate; ?>" required>
                </div>
                <div class="input-box">
                    <label>Address</label>
                    <input type="text" name="address" id="address" value="<?php echo $address; ?>" required>
                </div>
            </div>

            <div class="column">
                <div class="input-box">
                    <label>Phone</label>
                    <input type="text" name="phone" id="phone" value="<?php echo $phone; ?>" required>
                </div>
                <div class="input-box">
                    <label>Email</label>
                    <input type="email" name="email" id="email" value="<?php echo $email; ?>" required>
                </div>
            </div>

            <div class="column">
            <div class="input-box">
                    <label>Position</label>
                    <input type="text" name="position" id="position" value="<?php echo $position; ?>" required>
                </div>

                <div class="input-box">
                    <label>Education</label>
                    <input type="text" name="education" id="education" value="<?php echo $education; ?>" required>
                </div>
                <div class="input-box">
                    <label>Salary</label>
                    <input type="number" name="salary" id="salary" value="<?php echo $salary; ?>" required>
                </div>
            </div>


            <div class="button-div">
            <button type="submit" name="edit" class="button">Save Changes</button>
            </div>

        </form>
    </section>
</body>

</html>