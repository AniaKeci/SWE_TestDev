Delete X-Ray page.
<?php
include("database-configuration.php");

// Check if the X-Ray ID is provided in the URL parameters
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch the X-Ray details from the database
    $query = "SELECT XRay_File FROM xrays WHERE XRay_ID=?";
    $stmt = mysqli_prepare($connection, $query);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);

    if ($row) {
        $xrayFile = $row['XRay_File'];

        // Delete the X-Ray file from the server
        $filePath = 'uploaded_images/' . $xrayFile;
        if (file_exists($filePath)) {
            unlink($filePath);
        }

        // Delete the X-Ray record from the database
        $query = "DELETE FROM xrays WHERE XRay_ID=?";
        $stmt = mysqli_prepare($connection, $query);
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        header('Location: manage-xrays.php');
        exit;
    } else {
        echo "X-Ray not found.";
        exit();
    }
} else {
    header('Location: manage-xrays.php');
    exit;
}
?>