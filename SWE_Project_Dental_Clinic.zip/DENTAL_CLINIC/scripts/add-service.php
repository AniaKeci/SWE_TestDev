<?php
include("database-configuration.php");

// Checking if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $serviceName = $_POST['service_name'];
    $serviceFee = $_POST['service_fee'];
    $serviceDuration = $_POST['service_duration'];
    $departmentID = $_POST['department_id'];

    // Create the SQL query
    $query = "INSERT INTO service (Service_Name, Service_Fee, Service_Duration, Department_ID) VALUES (?, ?, ?, ?)";

    // Prepare the statement
    $stmt = mysqli_prepare($connection, $query);

    // Binding parameters to the statement
    mysqli_stmt_bind_param($stmt, "sdis", $serviceName, $serviceFee, $serviceDuration, $departmentID);

    // Execute and close the statement
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header('Location: manage-services.php');
    exit;
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/DENTAL_CLINIC/css/patient-signup.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <title>Dent-Assist | Add Service</title>
    <link rel="icon" href="/DENTAL_CLINIC/images/logo-color.png" type="image/png">
</head>

<body>
    <section class="container">
        <header>Add Service</header>

        <form method="post" class="form">
            <div class="column">
                <div class="input-box">
                    <label>Service Name</label>
                    <input type="text" name="service_name" id="service_name" required>
                </div>
            </div>
            <div class="column">
                <div class="input-box">
                    <label>Service Fee</label>
                    <input type="number" name="service_fee" id="service_fee" required>
                </div>
            </div>
            <div class="column">
                <div class="input-box">
                    <label>Service Duration</label>
                    <input type="text" name="service_duration" id="service_duration" required>
                </div>
            </div>
            <div class="column">
            <div class="input-box">
                    <label>Department</label>
                    <select name="department_id" id="department_id" required>
                        <option value="">Select Department</option>
                        <?php
                        $query = "SELECT * FROM department";
                        $result = mysqli_query($connection, $query);

                        if (mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<option value='" . $row['Department_ID'] . "'>" . $row['Department'] . "</option>";
                            }
                        }
                        ?>
                    </select>
                </div>
            </div>
            </div>

            <div class="button-div">
                <button type="submit" id="add-service" name="add_service" class="button">Add Service</button>
            </div>
        </form>
    </section>
</body>

</html>