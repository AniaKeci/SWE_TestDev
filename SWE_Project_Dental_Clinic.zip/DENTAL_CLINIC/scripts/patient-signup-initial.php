<?php
include("database-configuration.php");

// checking if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // retrieve form data
    $username = $_POST['username'];
    $password = $_POST['password'];
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $gender = $_['gender'];
    $birthdate = $_POST['birthdate'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $confirmpassword = $_POST['confirmpassword'];

    if ($password !== $confirmpassword) {
        echo "Passwords do not match.";
        exit;
    }

    // creating the SQL query
    $query = "INSERT INTO patient (Patient_Username, Patient_Password, Patient_Name, Patient_Surname, Patient_Gender, Patient_DateOfBirth, Patient_Address, Patient_PhoneNumber, Patient_Email) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    // preparing the statement
    $stmt = mysqli_prepare($connection, $query);

    // binding parameters to the statement
    mysqli_stmt_bind_param($stmt, "sssssssss", $username, $password, $name, $surname, $birthdate, $address, $phone, $email);

    // executing and closing the statement
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header('Location: patient-view.php');
    exit;
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width,, initial-scale=1">
    <link rel="stylesheet" href="css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a81368914c.js"></script>
    <link rel="icon" href="/DENTAL_CLINIC/images/logo-color.png" type="image/png">
    <link rel="stylesheet" href="/DENTAL_CLINIC/css/login.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&display=swap">
    <title>Dent-Assist | Patient Signup</title>
</head>

<body>
    <main>
        <div class="big-wrapper light">
            <header>
                <div class="container">
                    <div class="logo">
                        <a href="landing-page.php">
                        <img src="/DENTAL_CLINIC/images/logo.png" alt="Logo" class="image-logo">
                        </a>
                    </div>
                    <div class="links">
                        <ul>
                            <li><a href="admin-login.php">Admin Login</a></li>
                            <li><a href="staff-login.php">Student Login</a></li>
                            <li><a href="student-login.php">Student Login</a></li>
                            <li><a href="patient-login.php" class="btn">Patient Login</a></li>
                        </ul>
                    </div>
                </div>
            </header>

            <div class="showcase-area">
                <div class="container">
                    <div class="left">
                        <div class="left-image">
                            <img src="/DENTAL_CLINIC/images/signup-image.svg" class="signupimage">
                        </div>
                    </div>

                    <div class="right">
                    <form method="post">
                            <div class="input-div one">
                                <div class="i">
                                    <i class="fas fa-user"></i>
                                </div>
                                <div>
                                    <h5>Username</h5>
                                    <input class="input" type="text" name="username" id="username">
                                </div>
                            </div>

                            <div class="input-div one">
                                <div class="i">
                                    <i class="fas fa-user"></i>
                                </div>
                                <div>
                                    <h5>Name</h5>
                                    <input class="input" type="text" name="name" id="name">
                                </div>
                            </div>

                            <div class="input-div one">
                                <div class="i">
                                    <i class="fas fa-user"></i>
                                </div>
                                <div>
                                    <h5>Surname</h5>
                                    <input class="input" type="text" name="surname" id="surname">
                                </div>
                            </div>

                            <div class="input-div one">
                                <div class="i">
                                    <i class="fas fa-user"></i>
                                </div>
                                <div>
                                    <h5>Birthdate</h5>
                                    <input class="input" type="date" name="birthdate" id="birthdate">
                                </div>
                            </div>

                            <div class="input-div two">
                                <div class="i">
                                    <i class="fas fa-user"></i>
                                </div>
                                <div>
                                    <h5>Email</h5>
                                    <input class="input" type="ema" name="email" id="email">
                                </div>
                            </div>

                            <div class="input-div one">
                                <div class="i">
                                    <i class="fas fa-user"></i>
                                </div>
                                <div>
                                    <h5>Address</h5>
                                    <input class="input" type="text" name="address" id="address">
                                </div>
                            </div>

                            <div class="input-div one">
                                <div class="i">
                                    <i class="fas fa-user"></i>
                                </div>
                                <div>
                                    <h5>Phone</h5>
                                    <input class="input" type="text" name="phone" id="phone">
                                </div>
                            </div>

                            <div class="input-div three">
                                <div class="i">
                                    <i class="fas fa-lock"></i>
                                </div>
                                <div>
                                    <h5>Password</h5>
                                    <input class="input" type="password" name="password" id="password">
                                </div>
                            </div>

                            <div class="input-div four">
                                <div class="i">
                                    <i class="fas fa-lock"></i>
                                </div>
                                <div>
                                    <h5>Confirm Password</h5>
                                    <input class="input" type="password" name="confirmpassword" id="confirmpassword">
                                </div>
                            </div>
                            <button type="submit" id="signup" name="signup" class="button">Signup</button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="bottom-area">
                <div class="container">
                    <button class="toggle-btn">
                        <i></i>
                        <i></i>
                    </button>
                </div>
            </div>
        </div>
    </main>
    <script src="/DENTAL_CLINIC/javascript/login.js">
    </script>
</body>

</html>