<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width,, initial-scale=1.0">
    <link rel="stylesheet" href="/DENTAL_CLINIC/css/admin-dashboard.css">
    <title>Dent-Assist | Admin Dashboard</title>
    <link rel="icon" href="/DENTAL_CLINIC/images/logo-color.png" type="image/png">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />

</head>

<body>
    <div class="container">
        <aside>
            <div class="top">
                <div class="logo">
                    <img src="/DENTAL_CLINIC/images/logo.png" alt="logo">
                </div>
                <div class="close" id="close-btn">
                    <span class="material-symbols-sharp">close</span>
                </div>
            </div>

            <div class="sidebar">
                <a href="admin-view.php" class="active">
                    <span class="material-symbols-sharp">dashboard</span>
                    <h3>Dashboard</h3>
                </a>
                <a href="manage-staff.php">
                    <span class="material-symbols-sharp">person</span>
                    <h3>Staff Members</h3>
                </a>
                <a href="manage-students.php">
                    <span class="material-symbols-sharp">person</span>
                    <h3>Student Members</h3>
                </a> <a href="manage-patients.php">
                    <span class="material-symbols-sharp">person</span>
                    <h3>Patients</h3>
                </a>
                <a href="manage-emergency-contacts.php">
                    <span class="material-symbols-sharp">contact_phone</span>
                    <h3>Emergency Contacts</h3>
                </a>
                <a href="manage-appointments.php">
                    <span class="material-symbols-sharp">today</span>
                    <h3>Appointments</h3>
                </a>
                <a href="manage-xrays.php">
                    <span class="material-symbols-sharp">medical_information</span>
                    <h3>X-Rays</h3>
                </a>
                <a href="manage-departments.php">
                    <span class="material-symbols-sharp">domain</span>
                    <h3>Departments</h3>
                </a>
                <a href="manage-services.php">
                    <span class="material-symbols-sharp">medical_services</span>
                    <h3>Services</h3>
                </a>
                <a href="manage-notes.php">
                    <span class="material-symbols-sharp">sticky_note_2</span>
                    <h3>Notes</h3>
                </a>
                <a href="landing-page.php">
                    <span class="material-symbols-sharp">logout</span>
                    <h3>Logout</h3>
                </a>
            </div>
        </aside>
        <main>
            <h1>Dashboard</h1>
            <div class="date" id="current-time"></div>

            <div class="insights">
                <div class="staff">
                    <span class="material-symbols-sharp">clinical_notes</span>
                    <div class="middle">
                        <div class="left">
                            <h3>Staff Members</h3>
                            <?php
                            include("database-configuration.php");
                            $query = "SELECT * FROM staff";
                            $result = mysqli_query($connection, $query);

                            // Get the total number of staff members
                            $totalStaffMembers = mysqli_num_rows($result);

                            echo "<h1>" . $totalStaffMembers . "</h1>"; ?>
                        </div>
                        <div class="progress">
                            <!-- <svg>
                                <circle cx='38' cy='38' r='36'></circle>
                            </svg> -->
                            <div class="number">
                                <!-- <p>Total</p> -->
                            </div>
                        </div>
                    </div>
                    <small class="text-muted">Total Number</small>
                </div>
                <!-- END OF STAFF -->

                <div class="students">
                    <span class="material-symbols-sharp">supervisor_account</span>
                    <div class="middle">
                        <div class="left">
                            <h3>Student Members</h3>
                            <?php
                            include("database-configuration.php");
                            $query = "SELECT * FROM student";
                            $result = mysqli_query($connection, $query);

                            // Get the total number of staff members
                            $totalStudents = mysqli_num_rows($result);

                            echo "<h1>" . $totalStudents . "</h1>"; ?>
                        </div>
                        <div class="progress">
                            <!-- <svg>
                                <circle cx='38' cy='38' r='36'></circle>
                            </svg> -->
                            <div class="number">
                                <!-- <p>Total</p> -->
                            </div>
                        </div>
                    </div>
                    <small class="text-muted">Total Number</small>
                </div>
                <!-- END OF STUDENTS -->

                <div class="patients">
                    <span class="material-symbols-sharp">personal_injury</span>
                    <div class="middle">
                        <div class="left">
                            <h3>Patient Users</h3>
                            <?php
                            include("database-configuration.php");
                            $query = "SELECT * FROM patient";
                            $result = mysqli_query($connection, $query);

                            // Get the total number of staff members
                            $totalPatients = mysqli_num_rows($result);

                            echo "<h1>" . $totalPatients . "</h1>"; ?>                        </div>
                        <div class="progress">
                            <!-- <svg>
                                <circle cx='38' cy='38' r='36'></circle>
                            </svg> -->
                            <div class="number">
                                <!-- <p>Total</p> -->
                            </div>
                        </div>
                    </div>
                    <small class="text-muted">Total Number</small>
                </div>

                <div class="xrays">
                <span class="material-symbols-sharp">medical_information</span>
                    <div class="middle">
                        <div class="left">
                            <h3>X-Rays</h3>
                            <?php
                            include("database-configuration.php");
                            $query = "SELECT * FROM xrays";
                            $result = mysqli_query($connection, $query);

                            // Get the total number of staff members
                            $totalxrays = mysqli_num_rows($result);

                            echo "<h1>" . $totalxrays . "</h1>"; ?>
                        </div>
                        <div class="progress">
                            <!-- <svg>
                                <circle cx='38' cy='38' r='36'></circle>
                            </svg> -->
                            <div class="number">
                                <!-- <p>Total</p> -->
                            </div>
                        </div>
                    </div>
                    <small class="text-muted">Total Number</small>
                </div>

                <div class="departments">
                <span class="material-symbols-sharp">domain</span>
                    <div class="middle">
                        <div class="left">
                            <h3>Departments</h3>
                            <?php
                            include("database-configuration.php");
                            $query = "SELECT * FROM department";
                            $result = mysqli_query($connection, $query);

                            // Get the total number of staff members
                            $totaldepartments = mysqli_num_rows($result);

                            echo "<h1>" . $totaldepartments . "</h1>"; ?>
                        </div>
                        <div class="progress">
                            <!-- <svg>
                                <circle cx='38' cy='38' r='36'></circle>
                            </svg> -->
                            <div class="number">
                                <!-- <p>Total</p> -->
                            </div>
                        </div>
                    </div>
                    <small class="text-muted">Total Number</small>
                </div>
            </div>
        </main>
    </div>
    <script>
    // Function to update the current time
    function updateCurrentTime() {
        var currentTime = new Date();
        var hours = currentTime.getHours();
        var minutes = currentTime.getMinutes();
        var seconds = currentTime.getSeconds();

        // Format the time as "hh:mm:ss"
        var formattedTime = hours + " : " + minutes + " : " + seconds;

        // Update the content of the div with the current time
        document.getElementById("current-time").textContent = formattedTime;
    }

    // Call the updateCurrentTime function initially
    updateCurrentTime();

    // Call the updateCurrentTime function every second (1000 milliseconds)
    setInterval(updateCurrentTime, 1000);
</script>
</body>

</html>