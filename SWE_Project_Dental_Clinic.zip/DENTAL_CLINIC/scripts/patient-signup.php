<?php
include("database-configuration.php");

// checking if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // retrieve form data
    $username = $_POST['username'];
    $password = $_POST['password'];
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $gender = $_POST['gender']; // Retrieve the selected gender value
    $birthdate = $_POST['birthdate'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $confirmpassword = $_POST['confirmpassword'];

    if ($password !== $confirmpassword) {
        echo "Passwords do not match.";
        exit;
    }

    // creating the SQL query
    $query = "INSERT INTO patient (Patient_Username, Patient_Password, Patient_Name, Patient_Surname, Patient_Gender, Patient_DateOfBirth, Patient_Address, Patient_PhoneNumber, Patient_Email) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    // preparing the statement
    $stmt = mysqli_prepare($connection, $query);

    // binding parameters to the statement
    mysqli_stmt_bind_param($stmt, "sssssssss", $username, $password, $name, $surname, $gender, $birthdate, $address, $phone, $email); // Include the gender field

    // executing and closing the statement
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header('Location: patient-view.php');
    exit;
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width,, initial-scale=1.0">
    <link rel="stylesheet" href="/DENTAL_CLINIC/css/patient-signup.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <title>Dent-Assist | Patient Signup</title>
    <link rel="icon" href="/DENTAL_CLINIC/images/logo-color.png" type="image/png">
</head>

<body>
    <section class="container">
        <header>Registration Form</header>
        <form method="post" class="form">
        <div class="column">
            <div class="input-box">
                <label>Name</label>
                <input type="text" name="name" id="name" placeholder="Enter your name" required>
            </div>
            <div class="input-box">
                <label>Surname</label>
                <input type="text" name="surname" id="surname" placeholder="Enter your surname" required>
            </div>
        </div>

            <div class="column">
                <div class="input-box">
                    <label>Email</label>
                    <input type="email" name="email" id="email" placeholder="Enter your email" required>
                </div>
                <div class="input-box">
                    <label>Birth Date</label>
                    <input type="date" name="birthdate" id="birthdate" placeholder="Enter your birthdate" required>
                </div>
            </div>
            <div class="column">
                <div class="input-box">
                    <label>Phone</label>
                    <input type="text" name="phone" id="phone" placeholder="Enter your phone number" required>
                </div>
                <div class="input-box">
                    <label>Address</label>
                    <input type="text" name="address" id="address" placeholder="Enter your address" required>
                </div>
            </div>

            <div class="column">
            <div class="input-box">
                    <label>Username</label>
                    <input type="text" name="username" id="username" placeholder="Enter your username" required>
                </div>

                <div class="input-box">
                    <label>Password</label>
                    <input type="password" name="password" id="password" placeholder="Enter your password" required>
                </div>
                <div class="input-box">
                    <label> Confirm Password</label>
                    <input type="password" name="confirmpassword" id="confirmpassword" placeholder="Confirm password" required>
                </div>
            </div>

            <div class="gender-box">
                <h3>Gender</h3>
                <div class="gender-option">
                    <div class="gender">
                        <input type="radio" id="check-male" name="gender" value="Male">
                        <label for="check-male">Male</label>
                    </div>
                    <div class="gender">
                        <input type="radio" id="check-female" name="gender" value="Female">
                        <label for="check-female">Female</label>
                    </div>
                    <div class="gender">
                        <input type="radio" id="check-other" name="gender" value="Other">
                        <label for="check-other">Prefer not to say</label>
                    </div>
                </div>
            </div>
            <div class="button-div">
            <button type="submit" id="signup" name="signup" class="button">Signup</button>
            </div>

            <div class="main-page">
                <a href="landing-page.php" class="main-page-link">Go back to main page</a>
            </div>
        </form>
    </section>
</body>

</html>