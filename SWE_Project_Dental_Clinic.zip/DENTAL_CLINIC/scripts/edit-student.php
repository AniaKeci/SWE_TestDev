<?php
include("database-configuration.php");

// Check if the staff ID is provided in the URL parameters
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch the staff member's details from the database
    $query = "SELECT * FROM student WHERE Student_ID=?";
    $stmt = mysqli_prepare($connection, $query);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);

    // Check if the form has been submitted
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Retrieve form data
        $username = $_POST['username'];
        $password = $_POST['password'];
        $name = $_POST['name'];
        $surname = $_POST['surname'];
        $gender = $_POST['gender']; // Retrieve the selected gender value
        $birthdate = $_POST['birthdate'];
        $address = $_POST['address'];
        $phone = $_POST['phone'];
        $email = $_POST['email'];
        $academicyear = $_POST['academicyear'];

        // Update the staff member's details in the database
        $query = "UPDATE student SET Student_Username=?, Student_Password=?, Student_Name=?, Student_Surname=?, Student_Gender=?, Student_DateOfBirth=?, Student_Address=?, Student_PhoneNumber=?, Student_Email=?, Student_AcademicYear=? WHERE Student_ID=?";
        $stmt = mysqli_prepare($connection, $query);
        mysqli_stmt_bind_param($stmt, "ssssssssssi", $username, $password, $name, $surname, $gender, $birthdate, $address, $phone, $email, $academicyear, $id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        // Redirect to the manage staff page
        header('Location: manage-students.php');
        exit;
    }
} else {
    // If no staff ID is provided, redirect to the manage staff page
    header('Location: manage-students.php');
    exit;
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width,, initial-scale=1.0">
    <link rel="stylesheet" href="/DENTAL_CLINIC/css/patient-signup.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <title>Dent-Assist | Edit Student</title>
    <link rel="icon" href="/DENTAL_CLINIC/images/logo-color.png" type="image/png">
</head>

<body>
    <section class="container">
        <header>Edit Student Member</header>
        <?php
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch the student's details from the database
    $query = "SELECT * FROM student WHERE Student_ID=?";
    $stmt = mysqli_prepare($connection, $query);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);

    if ($row) {
        $username = $row["Student_Username"];
        $password = $row["Student_Password"];
        $name = $row["Student_Name"];
        $surname = $row["Student_Surname"];
        $gender = $row["Student_Gender"];
        $birthdate = $row["Student_DateOfBirth"];
        $address = $row["Student_Address"];
        $phone = $row["Student_PhoneNumber"];
        $email = $row["Student_Email"];
        $academicyear = $row["Student_AcademicYear"];
    } else {
        echo "Student member not found.";
        exit();
    }

    mysqli_stmt_close($stmt);
} else {
    echo "Student ID not provided.";
    exit();
}
?>
        <form method="post" class="form">
        <div class="column">
                <div class="input-box">
                    <label>Name</label>
                    <input type="text" name="name" id="name" value="<?php echo $name; ?>"required>
                </div>
                <div class="input-box">
                    <label>Surname</label>
                    <input type="text" name="surname" id="surname" value="<?php echo $surname; ?>"required>
                </div>
            </div>

            <div class="column">
                <div class="input-box">
                    <label>Email</label>
                    <input type="email" name="email" id="email" value="<?php echo $email; ?>"required>
                </div>
                <div class="input-box">
                    <label>Birth Date</label>
                    <input type="date" name="birthdate" id="birthdate" value="<?php echo $birthdate; ?>"required>
                </div>
            </div>
            <div class="column">
                <div class="input-box">
                    <label>Phone</label>
                    <input type="text" name="phone" id="phone" value="<?php echo $phone; ?>" required>
                </div>
                <div class="input-box">
                    <label>Address</label>
                    <input type="text" name="address" id="address" value="<?php echo $address; ?>" required>
                </div>
                <div class="input-box">
                    <label>Academic Year</label>
                    <input type="number" name="academicyear" id="academicyear" value="<?php echo $academicyear; ?>"required>
                </div>
            </div>

            <div class="column">
                <div class="input-box">
                    <label>Username</label>
                    <input type="text" name="username" id="username" value="<?php echo $username; ?>"required>
                </div>

                <div class="input-box">
                    <label>Password</label>
                    <input type="password" name="password" id="password" value="<?php echo $password; ?>"required>
                </div>
            </div>

            <div class="gender-box">
                <h3>Gender</h3>
                <div class="gender-option">
                    <div class="gender">
                        <input type="radio" id="check-male" name="gender" value="Male">
                        <label for="check-male">Male</label>
                    </div>
                    <div class="gender">
                        <input type="radio" id="check-female" name="gender" value="Female">
                        <label for="check-female">Female</label>
                    </div>
                    <div class="gender">
                        <input type="radio" id="check-other" name="gender" value="Other">
                        <label for="check-other">Prefer not to say</label>
                    </div>
                </div>
            </div>
            <div class="button-div">
                <button type="submit" id="signup" name="signup" class="button">Edit Student</button>
            </div>
        </form>
    </section>
</body>

</html>