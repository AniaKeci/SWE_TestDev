<?php
include("database-configuration.php");

// Check if the staff ID is provided in the URL parameters
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Delete the staff member from the database
    $query = "DELETE FROM student WHERE Student_ID=?";
    $stmt = mysqli_prepare($connection, $query);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    // Redirect to the manage staff page
    header('Location: manage-students.php');
    exit;
} else {
    // If no staff ID is provided, redirect to the manage staff page
    header('Location: manage-students.php');
    exit;
}
?>