<?php
include("database-configuration.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $date = $_POST['date'];
    $hour = $_POST['hour'];
    $status = $_POST['status'];
    $confirmation = date('Y-m-d H:i:s');
    $serviceid = $_POST['service'];
    $patientid = $_POST['patient'];
    $staffid = $_POST['staff'];
    $astaffid = $_POST['assistant_staff'];
    $studentid = $_POST['student'];

    $query = "INSERT INTO appointment (Appointment_Date, Appointment_Hour, Appointment_Status, Appointment_Confirmation, Service_ID, Patient_ID, Staff_ID, Assistant_Staff_ID, Student_ID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($connection, $query);

    mysqli_stmt_bind_param($stmt, "sssssssss", $date, $hour, $status, $confirmation, $serviceid, $patientid, $staffid, $astaffid, $studentid);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header('Location: manage-appointments.php');
    exit;
}

?>


<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/DENTAL_CLINIC/css/patient-signup.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <title>Dent-Assist | Add Appointment</title>
    <link rel="icon" href="/DENTAL_CLINIC/images/logo-color.png" type="image/png">
</head>

<body>
    <section class="container">
        <header>Add Appointment</header>

        <form method="post" class="form">
            <div class="column">
                <div class="input-box">
                    <label for="date">Date</label>
                    <input type="date" name="date" id="date" required>
                </div>
                <div class="input-box">
                    <label for="hour">Hour</label>
                    <input type="time" name="hour" id="hour" required>
                </div>
            </div>

            <div class="column">
                <div class="input-box">
                    <label for="service">Service</label>
                    <select name="service" id="service" required>
                        <?php
                        $query = "SELECT * FROM service";
                        $result = mysqli_query($connection, $query);

                        if (mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<option value='" . $row['Service_ID'] . "'>" . $row['Service_Name'] . "</option>";
                            }
                        }
                        ?>
                    </select>
                </div>
            </div>

            <div class="column">
                <div class="input-box">
                    <label for="status">Status</label>
                    <select name="status" id="status" required>
                        <option value="confirmed">Confirmed</option>
                        <option value="ongoing">Ongoing</option>
                        <option value="completed">Completed</option>
                    </select>
                </div>
            </div>

            <div class="column">
                <div class="input-box">
                    <label for="patient">Patient</label>
                    <select name="patient" id="patient" required>
                    <?php
                        $query = "SELECT * FROM patient";
                        $result = mysqli_query($connection, $query);

                        if (mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<option value='" . $row['Patient_ID'] . "'>" . $row['Patient_Name'] . " " . $row['Patient_Surname'] . "</option>";
                            }
                        }
                        ?>
                    </select>
                </div>
            </div>
            </div>

            <div class="column">
                <div class="input-box">
                    <label for="staff">Main Staff</label>
                    <select name="staff" id="staff" required>
                    <?php
                        $query = "SELECT * FROM staff";
                        $result = mysqli_query($connection, $query);

                        if (mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<option value='" . $row['Staff_ID'] . "'>" . $row['Staff_Name'] . " " . $row['Staff_Surname'] . "</option>";
                            }
                        }
                        ?>
                    </select>
                </div>

                <div class="input-box">
                    <label for="assistant_staff">A. Staff</label>
                    <select name="assistant_staff" id="assistant_staff" required>
                    <?php
                        $query = "SELECT * FROM staff";
                        $result = mysqli_query($connection, $query);

                        if (mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<option value='" . $row['Staff_ID'] . "'>" . $row['Staff_Name'] . " " . $row['Staff_Surname'] . "</option>";
                            }
                        }
                        ?>
                    </select>
                </div>

                <div class="input-box">
                    <label for="student">Student</label>
                    <select name="student" id="student" required>
                    <?php
                        $query = "SELECT * FROM student";
                        $result = mysqli_query($connection, $query);

                        if (mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_assoc($result)) {
                            echo "<option value='" . $row['Student_ID'] . "'>" . $row['Student_Name'] . " " . $row['Student_Surname'] . "</option>";
                            }
                        }
                        ?>
                    </select>
                </div>
            </div>
            </div>


            <div class="button-div">
                <button type="submit" id="add" name="add" class="button">Add</button>
            </div>
    </section>
</body>

</html>