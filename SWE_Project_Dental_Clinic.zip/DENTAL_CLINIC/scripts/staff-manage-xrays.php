<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width,, initial-scale=1.0">
    <link rel="stylesheet" href="/DENTAL_CLINIC/css/admin-dashboard.css">
    <title>Dent-Assist | Manage X-Rays</title>
    <link rel="icon" href="/DENTAL_CLINIC/images/logo-color.png" type="image/png">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />

</head>

<body>
    <div class="container">
    <aside>
            <div class="top">
                <div class="logo">
                    <img src="/DENTAL_CLINIC/images/logo.png" alt="logo">
                </div>
                <div class="close" id="close-btn">
                    <span class="material-symbols-sharp">close</span>
                </div>
            </div>

            <div class="sidebar">
                <a href="staff-view.php" class="active">
                    <span class="material-symbols-sharp">dashboard</span>
                    <h3>Dashboard</h3>
                </a>
                <a href="staff-manage-students.php">
                    <span class="material-symbols-sharp">person</span>
                    <h3>Student Members</h3>
                </a>
                <a href="staff-manage-patients.php">
                    <span class="material-symbols-sharp">person</span>
                    <h3>Patients</h3>
                </a>
                <a href="staff-manage-emergency-contacts.php">
                    <span class="material-symbols-sharp">contact_phone</span>
                    <h3>Emergency Contacts</h3>
                </a>
                <a href="staff-manage-appointments.php">
                    <span class="material-symbols-sharp">today</span>
                    <h3>Appointments</h3>
                </a>
                <a href="staff-manage-xrays.php" class="active">
                    <span class="material-symbols-sharp">medical_information</span>
                    <h3>X-Rays</h3>
                </a>
                <a href="staff-manage-services.php">
                    <span class="material-symbols-sharp">medical_services</span>
                    <h3>Services</h3>
                </a>
                <a href="staff-manage-notes.php">
                    <span class="material-symbols-sharp">sticky_note_2</span>
                    <h3>Notes</h3>
                </a>
                <a href="landing-page.php">
                    <span class="material-symbols-sharp">logout</span>
                    <h3>Logout</h3>
                </a>
            </div>
        </aside>
        <main>
            <h1>Dashboard</h1>
            <div class="date" id="current-time"></div>

            <div class="sample-table">
                <h2>X-Rays</h2>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Type</th>
                            <th>Image</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include("database-configuration.php");
                        $query = "SELECT * FROM xrays";
                        $result = mysqli_query($connection, $query);

                        if (mysqli_num_rows($result) > 0) {
                            $i = 1;
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<tr>";
                                echo "<td>" . $i++ . "</td>";
                                echo "<td>" . $row["XRay_Type"] . "</td>";
                                echo "<td> <img src=\"uploaded_images/" . $row["XRay_File"] . "\" width=\"200\" title=\"" . $row['XRay_File'] . "\"> </td>";
                                echo "<td>";
                                echo "<button type='button' class='edit-button' onclick=\"location.href='edit-xray.php?id=" . $row['XRay_ID'] . "'\">Edit</button>";
                                echo "<br><br>";
                                echo "<button type='button' class='delete-button' onclick=\"location.href='delete-xray.php?id=" . $row['XRay_ID'] . "'\">Delete</button>";
                                echo "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "0 results";
                        }
                        ?>
                    </tbody>
                </table>
            </div>

            <div>
                <a href="add-xray.php" class="text-muted">Add X-Ray</a>
            </div>
        </main>
    </div>
    <script>
        // Function to update the current time
        function updateCurrentTime() {
            var currentTime = new Date();
            var hours = currentTime.getHours();
            var minutes = currentTime.getMinutes();
            var seconds = currentTime.getSeconds();

            // Format the time as "hh:mm:ss"
            var formattedTime = hours + " : " + minutes + " : " + seconds;

            // Update the content of the div with the current time
            document.getElementById("current-time").textContent = formattedTime;
        }

        // Call the updateCurrentTime function initially
        updateCurrentTime();

        // Call the updateCurrentTime function every second (1000 milliseconds)
        setInterval(updateCurrentTime, 1000);
    </script>
</body>

</html>