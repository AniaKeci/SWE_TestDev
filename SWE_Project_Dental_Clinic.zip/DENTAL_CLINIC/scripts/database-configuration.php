<?php
$hostname = "localhost";
$username = "root";
$password = "";
$database = "dental_clinic_database";

// Establish database connection
$connection = mysqli_connect($hostname, $username, $password, $database);

// Check if the connection was successful
if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}
?>