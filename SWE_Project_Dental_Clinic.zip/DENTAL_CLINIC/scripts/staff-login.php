<?php
include("database-configuration.php");

if (isset($_POST['login'])) {
    // Retrieve the values from the form
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Perform a query to check if the username and password match
    $query = "SELECT * FROM staff WHERE (Staff_Username='$username' OR Staff_Email='$username') AND Staff_Password='$password'";
    $result = mysqli_query($connection, $query);

    // Check if the query was successful
    if (mysqli_num_rows($result) == 1) {
        // Login successful, redirect to admin-view.php
        header("Location: staff-view.php");
        exit();
    } else {
        // Login failed, display an error message
        echo "Invalid username or password.";
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width,, initial-scale=1">
    <link rel="stylesheet" href="css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a81368914c.js"></script>
    <link rel="icon" href="/DENTAL_CLINIC/images/logo-color.png" type="image/png">
    <link rel="stylesheet" href="/DENTAL_CLINIC/css/login.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&display=swap">
    <title>Dent-Assist | Staff Login</title>
</head>

<body>
    <main>
        <div class="big-wrapper light">
            <header>
                <div class="container">
                    <div class="logo">
                        <a href="landing-page.php">
                            <img src="/DENTAL_CLINIC/images/logo.png" alt="Logo" class="image-logo">
                        </a>
                    </div>
                    <div class="links">
                        <ul>
                            <li><a href="staff-login.php">Admin Login</a></li>
                            <li><a href="student-login.php">Student Login</a></li>
                            <li><a href="patient-login.php" class="btn">Patient Login</a></li>
                        </ul>
                    </div>
                </div>
            </header>

            <div class="showcase-area">
                <div class="container">
                    <div class="left">
                        <div class="left-image">
                            <img src="/DENTAL_CLINIC/images/login-image.svg" class="loginimage">
                        </div>
                    </div>

                    <div class="right">
                        <form method="post">
                            <div class="input-div one">
                                <div class="i">
                                    <i class="fas fa-user"></i>
                                </div>
                                <div>
                                    <h5>Username or Email</h5>
                                    <input class="input" type="text" name="username" id="username">
                                </div>
                            </div>

                            <div class="input-div two">
                                <div class="i">
                                    <i class="fas fa-lock"></i>
                                </div>
                                <div>
                                    <h5>Password</h5>
                                    <input class="input" type="password" name="password" id="password">
                                </div>
                            </div>
                            <button type="submit" id="login" name="login" class="button">Login</button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="bottom-area">
                <div class="container">
                    <button class="toggle-btn">
                        <i></i>
                        <i></i>
                    </button>
                </div>
            </div>
        </div>
    </main>
    <script src="/DENTAL_CLINIC/javascript/login.js">
    </script>
</body>

</html>