<?php
include("database-configuration.php");

// Check if the X-ray ID is provided in the URL parameters
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch the X-ray details from the database
    $query = "SELECT * FROM xrays WHERE XRay_ID=?";
    $stmt = mysqli_prepare($connection, $query);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);

    // Check if the X-ray exists
    if ($row) {
        $id = $row['XRay_ID'];
        $type = $row['XRay_Type'];
        $image = $row['XRay_File'];

        // Check if the form has been submitted
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Retrieve form data
            $newType = $_POST['type'];

            // Check if a new image file has been uploaded
            if ($_FILES["image"]["error"] != 4) {
                $fileName = $_FILES["image"]["name"];
                $fileSize = $_FILES["image"]["size"];
                $tmpName = $_FILES["image"]["tmp_name"];

                $validImageExtension = ['jpg', 'jpeg', 'png'];

                $imageExtension = explode('.', $fileName);
                $imageExtension = strtolower(end($imageExtension));

                if (!in_array($imageExtension, $validImageExtension)) {
                    echo "Invalid Image Extension";
                    exit();
                } else if ($fileSize > 1000000) {
                    echo "Image Size Is Too Large";
                    exit();
                } else {
                    // Generate a unique name for the new image
                    $newImageName = uniqid();
                    $newImageName .= '.' . $imageExtension;

                    // Move the uploaded image to the desired location
                    move_uploaded_file($tmpName, 'uploaded_images/' . $newImageName);

                    // Delete the previous image file
                    unlink('uploaded_images/' . $image);

                    // Update the X-ray details with the new image and type in the database
                    $query = "UPDATE xrays SET XRay_Type=?, XRay_File=? WHERE XRay_ID=?";
                    $stmt = mysqli_prepare($connection, $query);
                    mysqli_stmt_bind_param($stmt, "ssi", $newType, $newImageName, $id);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_close($stmt);
                }
            } else {
                // Only update the X-ray type if no new image file is uploaded
                $query = "UPDATE xrays SET XRay_Type=? WHERE XRay_ID=?";
                $stmt = mysqli_prepare($connection, $query);
                mysqli_stmt_bind_param($stmt, "si", $newType, $id);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);
            }

            // Redirect to the manage X-rays page
            header('Location: manage-xrays.php');
            exit;
        }
    } else {
        echo "X-ray not found.";
        exit();
    }
} else {
    // If no X-ray ID is provided, redirect to the manage X-rays page
    header('Location: manage-xrays.php');
    exit;
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width,, initial-scale=1.0">
    <link rel="stylesheet" href="/DENTAL_CLINIC/css/patient-signup.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <title>Dent-Assist | Add X-Ray</title>
    <link rel="icon" href="/DENTAL_CLINIC/images/logo-color.png" type="image/png">
</head>

<body>
    <section class="container">
        <header>Edit X-Ray</header>

        <form method="post" class="form" enctype="multipart/form-data">
            <div class="column">
                <div class="input-box">
                    <label>Type</label>
                    <input type="text" name="name" id="name" value="<?php echo $type; ?>"required>
                </div>
            </div>
            <br>
            <div class="column">
                <label>Image</label>
                <input type="file" name="image" id="image" accept=".jpg, .jpeg, .png" value=""> <br> <br>
            </div>

            <div class="button-div">
                <button type="submit" id="add" name="add" class="button">Save</button>
            </div>
        </form>
    </section>
</body>

</html>