<?php
include("database-configuration.php");

// checking if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // retrieve form data
    $name = $_POST['name'];

    // creating the SQL query
    $query = "INSERT INTO department (Department) VALUES (?)";

    // preparing the statement
    $stmt = mysqli_prepare($connection, $query);

    // binding parameters to the statement
    mysqli_stmt_bind_param($stmt, "s", $name);

    // executing and closing the statement
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header('Location: manage-departments.php');
    exit;
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/DENTAL_CLINIC/css/patient-signup.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <title>Dent-Assist | Add Department</title>
    <link rel="icon" href="/DENTAL_CLINIC/images/logo-color.png" type="image/png">
</head>

<body>
    <section class="container">
        <header>Add Department</header>

        <form method="post" class="form">
            <div class="column">
                <div class="input-box">
                    <label>Department</label>
                    <input type="text" name="name" id="name" required>
                </div>
            </div>

            <div class="button-div">
                <button type="submit" id="add-department" name="add_department" class="button">Add Department</button>
            </div>

        </form>
    </section>
</body>

</html>