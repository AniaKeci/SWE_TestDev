<?php
include("database-configuration.php");

// checking if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // retrieve form data
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $relation = $_POST['relation'];
    $phoneNumber = $_POST['phone_number'];
    $email = $_POST['email'];
    $patientID = $_POST['patient'];

    // creating the SQL query
    $query = "INSERT INTO emergencycontact (Contact_Name, Contact_Surname, Contact_Relation, Contact_Phone_Number, Contact_Email, Patient_ID) VALUES (?, ?, ?, ?, ?, ?)";

    // preparing the statement
    $stmt = mysqli_prepare($connection, $query);

    // binding parameters to the statement
    mysqli_stmt_bind_param($stmt, "ssssss", $name, $surname, $relation, $phoneNumber, $email, $patientID);

    // executing and closing the statement
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header('Location: manage-emergency-contacts.php');
    exit;
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/DENTAL_CLINIC/css/patient-signup.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <title>Dent-Assist | Add Emergency Contact</title>
    <link rel="icon" href="/DENTAL_CLINIC/images/logo-color.png" type="image/png">
</head>

<body>
    <section class="container">
        <header>Add Emergency Contact</header>

        <form method="post" class="form">
            <div class="column">
                <div class="input-box">
                    <label>Name</label>
                    <input type="text" name="name" id="name" required>
                </div>
                <div class="input-box">
                    <label>Surname</label>
                    <input type="text" name="surname" id="surname" required>
                </div>
            </div>

            <div class="column">
                <div class="input-box">
                    <label>Relation</label>
                    <input type="text" name="relation" id="relation" required>
                </div>
                <div class="input-box">
                    <label>Phone Number</label>
                    <input type="text" name="phone_number" id="phone_number" required>
                </div>
            </div>
            <div class="column">
                <div class="input-box">
                    <label>Email</label>
                    <input type="email" name="email" id="email" required>
                </div>
                <div class="input-box">
                    <label>Patient Name</label>
                    <br><br>
                    <select id="patient" name="patient" required>
                        <?php
                        $query = "SELECT * FROM patient";
                        $result = mysqli_query($connection, $query);

                        if (mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<option value='" . $row['Patient_ID'] . "'>" . $row['Patient_Name'] . " " . $row['Patient_Surname'] . "</option>";
                            }
                        }
                        ?>
                    </select>
                </div>
            </div>

            <div class="button-div">
                <button type="submit" id="add-contact" name="add_contact" class="button">Add Contact</button>
            </div>
        </form>
    </section>
</body>

</html>