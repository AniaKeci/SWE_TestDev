<?php
include("database-configuration.php");

// Check if the emergency contact ID is provided in the URL parameters
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Retrieve the emergency contact details from the database
    $query = "SELECT * FROM department WHERE Department_ID=?";
    $stmt = mysqli_prepare($connection, $query);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($result)) {
        $dep = $row['Department'];
    } else {
        // Redirect to the manage emergency contacts page if the emergency contact is not found
        header('Location: manage-departments.php');
        exit;
    }

    mysqli_stmt_close($stmt);
} else {
    // Redirect to the manage emergency contacts page if the emergency contact ID is not provided
    header('Location: manage-departments.php');
    exit;
}

// Check if the form has been submitted for updating the emergency contact
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $dep = $_POST['name'];

    // Update the emergency contact in the database
    $query = "UPDATE department SET Department=? WHERE Department_ID=?";
    $stmt = mysqli_prepare($connection, $query);
    mysqli_stmt_bind_param($stmt, "si", $dep, $id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header('Location: manage-departments.php');
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/DENTAL_CLINIC/css/patient-signup.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <title>Dent-Assist | Edit Department</title>
    <link rel="icon" href="/DENTAL_CLINIC/images/logo-color.png" type="image/png">
</head>
<body>
    <section class="container">
        <header>Edit Department</header>
        <form method="POST" action="edit-department.php?id=<?php echo $id; ?>" class="form">
            <div class="column">
                <div class="input-box">
                    <label>Name:</label>
                    <input type="text" id="name" name="name" value="<?php echo $dep; ?>" required>
                </div>
            </div>


            <div class="button-div">
                <button type="submit" id="update" name="update" class="button">Update</button>
            </div>
        </form>
    </section>
</body>
</html>
