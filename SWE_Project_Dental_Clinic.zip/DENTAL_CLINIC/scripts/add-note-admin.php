<?php
include("database-configuration.php");

// Checking if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $id = $_POST['id'];
    $message = $_POST['message'];
    $timestamp = $_POST['duration'];
    $author = $_POST['author'];

    // Create the SQL query
    $query = "INSERT INTO note (Note_ID, Note_Message, Note_Timestamp, Note_Author) VALUES (?, ?, ?, ?)";

    // Prepare the statement
    $stmt = mysqli_prepare($connection, $query);

    // Binding parameters to the statement
    mysqli_stmt_bind_param($stmt, "isss", $id, $message, $timestamp, $author);

    // Execute and close the statement
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header('Location: manage-notes.php');
    exit;
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/DENTAL_CLINIC/css/patient-signup.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <title>Dent-Assist | Add Note</title>
    <link rel="icon" href="/DENTAL_CLINIC/images/logo-color.png" type="image/png">
</head>

<body>
    <section class="container">
        <header>Add Note</header>

        <form method="post" class="form">
            <div class="column">
                <div class="input-box">
                    <label>Note</label>
                    <input type="text" name="message" id="message" required>
                </div>
            </div>
            <div class="column">
            <div class="input-box">
                    <label>Admin</label>
                    <select name="author" id="author" required>
                        <option value="">Select Admin</option>
                        <?php
                        $query = "SELECT * FROM admin";
                        $result = mysqli_query($connection, $query);

                        if (mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<option value='" . $row['Admin_ID'] . "'>" . $row['Admin_Name'] . "  ". $row['Admin_Surname'] . "</option>";
                            }
                        }
                        ?>
                    </select>
                </div>
            </div>
            </div>

            <div class="button-div">
                <button type="submit" id="add-note" name="add_note" class="button">Add Note</button>
            </div>
        </form>
    </section>
</body>

</html>