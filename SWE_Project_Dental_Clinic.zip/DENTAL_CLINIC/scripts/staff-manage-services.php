<?php
include("database-configuration.php");

$query = "SELECT * FROM service";
$result = mysqli_query($connection, $query);
?>

<!DOCTYPE html>
<html>
<head><meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/DENTAL_CLINIC/css/admin-dashboard.css">
    <title>Dent-Assist | Admin Dashboard</title>
    <link rel="icon" href="/DENTAL_CLINIC/images/logo-color.png" type="image/png">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />

</head>
<body>
    <div class="container">
    <aside>
            <div class="top">
                <div class="logo">
                    <img src="/DENTAL_CLINIC/images/logo.png" alt="logo">
                </div>
                <div class="close" id="close-btn">
                    <span class="material-symbols-sharp">close</span>
                </div>
            </div>

            <div class="sidebar">
                <a href="staff-view.php">
                    <span class="material-symbols-sharp">dashboard</span>
                    <h3>Dashboard</h3>
                </a>
                <a href="staff-manage-students.php">
                    <span class="material-symbols-sharp">person</span>
                    <h3>Student Members</h3>
                </a>
                <a href="staff-manage-patients.php">
                    <span class="material-symbols-sharp">person</span>
                    <h3>Patients</h3>
                </a>
                <a href="staff-manage-emergency-contacts.php">
                    <span class="material-symbols-sharp">contact_phone</span>
                    <h3>Emergency Contacts</h3>
                </a>
                <a href="staff-manage-appointments.php">
                    <span class="material-symbols-sharp">today</span>
                    <h3>Appointments</h3>
                </a>
                <a href="staff-manage-xrays.php">
                    <span class="material-symbols-sharp">medical_information</span>
                    <h3>X-Rays</h3>
                </a>
                <a href="staff-manage-services.php" class="active">
                    <span class="material-symbols-sharp">medical_services</span>
                    <h3>Services</h3>
                </a>
                <a href="staff-manage-notes.php">
                    <span class="material-symbols-sharp">sticky_note_2</span>
                    <h3>Notes</h3>
                </a>
                <a href="landing-page.php">
                    <span class="material-symbols-sharp">logout</span>
                    <h3>Logout</h3>
                </a>
            </div>
        </aside>
        <main>
            <h1>Manage Services</h1>
            <div class="sample-table">
                <h2>Services</h2>
                <table>
                    <thead>
                        <tr>
                            <th>Service ID</th>
                            <th>Service Name</th>
                            <th>Service Fee</th>
                            <th>Service Duration</th>
                            <th>Department ID</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<tr>";
                                echo "<td>" . $row['Service_ID'] . "</td>";
                                echo "<td>" . $row['Service_Name'] . "</td>";
                                echo "<td>" . $row['Service_Fee'] . "</td>";
                                echo "<td>" . $row['Service_Duration'] . "</td>";
                                echo "<td>" . $row['Department_ID'] . "</td>";
                                echo "<td>";
                                echo "<button type='button' class='edit-button' onclick=\"location.href='edit-service.php?id=" . $row['Service_ID'] . "'\">Edit</button>";
                                echo "<br><br>";
                                echo "<button type='button'class='delete-button' onclick=\"location.href='delete-service.php?id=" . $row['Service_ID'] . "'\">Delete</button>";
                                echo "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='6'>No services found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            <div>
                <a href="add-service.php" class="text-muted">Add Service</a>
            </div>
        </main>
    </div>
    <script>
        // Function to update the current time
        function updateCurrentTime() {
            var currentTime = new Date();
            var hours = currentTime.getHours();
            var minutes = currentTime.getMinutes();
            var seconds = currentTime.getSeconds();

            // Format the time as "hh:mm:ss"
            var formattedTime = hours + " : " + minutes + " : " + seconds;

            // Update the content of the div with the current time
            document.getElementById("current-time").textContent = formattedTime;
        }

        // Call the updateCurrentTime function initially
        updateCurrentTime();

        // Call the updateCurrentTime function every second (1000 milliseconds)
        setInterval(updateCurrentTime, 1000);
    </script>
</body>
</html>
