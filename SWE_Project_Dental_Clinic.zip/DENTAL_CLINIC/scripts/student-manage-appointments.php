<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/DENTAL_CLINIC/css/admin-dashboard.css">
    <title>Dent-Assist | Manage Appointments</title>
    <link rel="icon" href="/DENTAL_CLINIC/images/logo-color.png" type="image/png">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
</head>

<body>
    <div class="container">
        <aside>
            <div class="top">
                <div class="logo">
                    <img src="/DENTAL_CLINIC/images/logo.png" alt="logo">
                </div>
                <div class="close" id="close-btn">
                    <span class="material-symbols-sharp">close</span>
                </div>
            </div>

            <div class="sidebar">
                <a href="student-view.php">
                    <span class="material-symbols-sharp">dashboard</span>
                    <h3>Dashboard</h3>
                </a>
                <a href="student-manage-patients.php">
                    <span class="material-symbols-sharp">person</span>
                    <h3>Patients</h3>
                </a>
                <a href="student-manage-emergency-contacts.php">
                    <span class="material-symbols-sharp">contact_phone</span>
                    <h3>Emergency Contacts</h3>
                </a>
                <a href="student-manage-appointments.php" class="active">
                    <span class="material-symbols-sharp">today</span>
                    <h3>Appointments</h3>
                </a>
                <a href="student-manage-xrays.php">
                    <span class="material-symbols-sharp">medical_information</span>
                    <h3>X-Rays</h3>
                </a>
                <a href="student-manage-notes.php">
                    <span class="material-symbols-sharp">sticky_note_2</span>
                    <h3>Notes</h3>
                </a>
                <a href="landing-page.php">
                    <span class="material-symbols-sharp">logout</span>
                    <h3>Logout</h3>
                </a>
            </div>
        </aside>
        <main>
            <h1>Dashboard</h1>
            <div class="date" id="current-time"></div>

            <div class="sample-table">
                <h2>Appointments</h2>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Date</th>
                            <th>Hour</th>
                            <th>Status</th>
                            <th>Confirmation</th>
                            <th>Service</th>
                            <th>Patient</th>
                            <th>Staff</th>
                            <th>Assistant Staff</th>
                            <th>Student</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        include("database-configuration.php");

                        $query = "SELECT Appointment.Appointment_ID, Appointment.Appointment_Date, Appointment.Appointment_Hour, Appointment.Appointment_Status, Appointment.Appointment_Confirmation, 
            Service.Service_Name, 
            CONCAT(Patient.Patient_Name, ' ', Patient.Patient_Surname) AS Patient_Name,
            CONCAT(Staff.Staff_Name, ' ', Staff.Staff_Surname) AS Staff_Name,
            CONCAT(AssistantStaff.Staff_Name, ' ', AssistantStaff.Staff_Surname) AS Assistant_Staff_Name,
            CONCAT(Student.Student_Name, ' ', Student.Student_Surname) AS Student_Name
          FROM Appointment
          INNER JOIN Service ON Appointment.Service_ID = Service.Service_ID
          INNER JOIN Patient ON Appointment.Patient_ID = Patient.Patient_ID
          INNER JOIN Staff ON Appointment.Staff_ID = Staff.Staff_ID
          INNER JOIN Staff AS AssistantStaff ON Appointment.Assistant_Staff_ID = AssistantStaff.Staff_ID
          INNER JOIN Student ON Appointment.Student_ID = Student.Student_ID";

                        $result = mysqli_query($connection, $query);

                        if (mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<tr>";
                                echo "<td>" . $row['Appointment_ID'] . "</td>";
                                echo "<td>" . $row['Appointment_Date'] . "</td>";
                                echo "<td>" . $row['Appointment_Hour'] . "</td>";
                                echo "<td>" . $row['Appointment_Status'] . "</td>";
                                echo "<td>" . $row['Appointment_Confirmation'] . "</td>";
                                echo "<td>" . $row['Service_Name'] . "</td>";
                                echo "<td>" . $row['Patient_Name'] . "</td>";
                                echo "<td>" . $row['Staff_Name'] . "</td>";
                                echo "<td>" . $row['Assistant_Staff_Name'] . "</td>";
                                echo "<td>" . $row['Student_Name'] . "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='11'>No appointments found.</td></tr>";
                        }

                        ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
    <script>
        // Function to update the current time
        function updateCurrentTime() {
            var currentTime = new Date();
            var hours = currentTime.getHours();
            var minutes = currentTime.getMinutes();
            var seconds = currentTime.getSeconds();

            // Format the time as "hh:mm:ss"
            var formattedTime = hours + " : " + minutes + " : " + seconds;

            // Update the content of the div with the current time
            document.getElementById("current-time").textContent = formattedTime;
        }

        // Call the updateCurrentTime function initially
        updateCurrentTime();

        // Call the updateCurrentTime function every second (1000 milliseconds)
        setInterval(updateCurrentTime, 1000);
    </script>
</body>

</html>