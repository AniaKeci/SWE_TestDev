<?php
include("database-configuration.php");

// Check if the patient ID is provided in the URL parameters
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch the patient's details from the database
    $query = "SELECT * FROM patient WHERE Patient_ID=?";
    $stmt = mysqli_prepare($connection, $query);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);

    // Check if the form has been submitted
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Retrieve form data
        $username = $_POST['username'];
        $password = $_POST['password'];
        $name = $_POST['name'];
        $surname = $_POST['surname'];
        $gender = $_POST['gender']; // Retrieve the selected gender value
        $birthdate = $_POST['birthdate'];
        $address = $_POST['address'];
        $phone = $_POST['phone'];
        $email = $_POST['email'];

        // Update the patient's details in the database
        $query = "UPDATE patient SET Patient_Username=?, Patient_Password=?, Patient_Name=?, Patient_Surname=?, Patient_Gender=?, Patient_DateOfBirth=?, Patient_Address=?, Patient_PhoneNumber=?, Patient_Email=? WHERE Patient_ID=?";
        $stmt = mysqli_prepare($connection, $query);
        mysqli_stmt_bind_param($stmt, "sssssssssi", $username, $password, $name, $surname, $gender, $birthdate, $address, $phone, $email, $id);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        // Redirect to the manage patients page
        header('Location: manage-patients.php');
        exit;
    }
} else {
    // If no patient ID is provided, redirect to the manage patients page
    header('Location: manage-patients.php');
    exit;
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/DENTAL_CLINIC/css/patient-signup.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <title>Dent-Assist | Edit Patient</title>
    <link rel="icon" href="/DENTAL_CLINIC/images/logo-color.png" type="image/png">
</head>

<body>
    <section class="container">
        <header>Edit Patient</header>
        <?php
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch the patient's details from the database
    $query = "SELECT * FROM patient WHERE Patient_ID=?";
    $stmt = mysqli_prepare($connection, $query);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);

    if ($row) {
        $username = $row["Patient_Username"];
        $password = $row["Patient_Password"];
        $name = $row["Patient_Name"];
        $surname = $row["Patient_Surname"];
        $gender = $row["Patient_Gender"];
        $birthdate = $row["Patient_DateOfBirth"];
        $address = $row["Patient_Address"];
        $phone = $row["Patient_PhoneNumber"];
        $email = $row["Patient_Email"];
    } else {
        echo "Patient not found.";
        exit();
    }

    mysqli_stmt_close($stmt);
} else {
    echo "Patient ID not provided.";
    exit();
}
?>
        <form method="post" class="form">
            <div class="column">
                <div class="input-box">
                    <label>Name</label>
                    <input type="text" name="name" id="name" value="<?php echo $name; ?>" required>
                </div>
                <div class="input-box">
                    <label>Surname</label>
                    <input type="text" name="surname" id="surname" value="<?php echo $surname; ?>" required>
                </div>
            </div>

            <div class="column">
                <div class="input-box">
                    <label>Email</label>
                    <input type="email" name="email" id="email" value="<?php echo $email; ?>" required>
                </div>
                <div class="input-box">
                    <label>Birth Date</label>
                    <input type="date" name="birthdate" id="birthdate" value="<?php echo $birthdate; ?>" required>
                </div>
            </div>
            <div class="column">
                <div class="input-box">
                    <label>Phone</label>
                    <input type="text" name="phone" id="phone" value="<?php echo $phone; ?>" required>
                </div>
                <div class="input-box">
                    <label>Address</label>
                    <input type="text" name="address" id="address" value="<?php echo $address; ?>" required>
                </div>
            </div>

            <div class="column">
                <div class="input-box">
                    <label>Username</label>
                    <input type="text" name="username" id="username" value="<?php echo $username; ?>" required>
                </div>

                <div class="input-box">
                    <label>Password</label>
                    <input type="password" name="password" id="password" value="<?php echo $password; ?>" required>
                </div>
            </div>

            <div class="gender-box">
                <h3>Gender</h3>
                <div class="gender-option">
                    <div class="gender">
                        <input type="radio" id="check-male" name="gender" value="Male" <?php if ($gender === 'Male') echo 'checked'; ?>>
                        <label for="check-male">Male</label>
                    </div>
                    <div class="gender">
                        <input type="radio" id="check-female" name="gender" value="Female" <?php if ($gender === 'Female') echo 'checked'; ?>>
                        <label for="check-female">Female</label>
                    </div>
                    <div class="gender">
                        <input type="radio" id="check-other" name="gender" value="Other" <?php if ($gender === 'Other') echo 'checked'; ?>>
                        <label for="check-other">Prefer not to say</label>
                    </div>
                </div>
            </div>
            <div class="button-div">
                <button type="submit" id="signup" name="signup" class="button">Edit Patient</button>
            </div>

        </form>
    </section>
</body>

</html>
