<?php
include("database-configuration.php");
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="/DENTAL_CLINIC/images/logo-color.png" type="image/png">
    <title>Dent-Assist | Landing Page</title>
    <link rel="stylesheet" href="/DENTAL_CLINIC/css/landing-page.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&display=swap">
</head>

<body>
    <main>
        <div class="big-wrapper light">
            <img src="/DENTAL_CLINIC/images/landing-page-shape.png" alt="shape" class="shape">
            <header>
                <div class="container">
                    <div class="logo">
                        <img src="/DENTAL_CLINIC/images/logo.png" alt="Logo" class="image-logo">
                    </div>
                    <div class="links">
                        <ul>
                            <li><a href="admin-login.php">Admin Login</a></li>
                            <li><a href="staff-login.php">Staff Login</a></li>
                            <li><a href="student-login.php">Student Login</a></li>
                            <li><a href="patient-login.php" class="btn">Patient Login</a></li> <!-- button -->
                        </ul>
                    </div>

                    <div class="overlay"></div>

                    <div class="hamburger-menu">
                        <div class="bar"></div>
                    </div>

                </div>
            </header>

            <div class="showcase-area">
                <div class="container">
                    <div class="left">
                        <div class="big-title">
                            <h1>Enhance efficiency, enhance smiles.</h1>
                        </div>
                        <p class="text">
                        Discover the benefits of our Dental Clinic Management System and revolutionize the way you manage your dental practice. Join us on this journey towards enhanced efficiency, improved patient care, and overall practice success.                        </p>
                        <div class="cta">
                            <a href="patient-signup.php" class="btn">Get Started</a>
                        </div>
                    </div>

                    <div class="right">
                        <img src="/DENTAL_CLINIC/images/landing-page-image.svg" alt="Dental Clinic Assist System" class="landing-page-image">
                    </div>
                </div>

            </div>
            <div class="bottom-area">
                <div class="container">
                    <button class="toggle-btn">
                        <i class="far fa-moon"></i>
                        <i class="far fa-sun"></i>
                    </button>
                </div>
            </div>
        </div>
    </main>

    <script src="https://kit.fontawesome.com/a81368914c.js"></script>
    <script src="/DENTAL_CLINIC/javascript/landing-page.js"></script>
</body>

</html>