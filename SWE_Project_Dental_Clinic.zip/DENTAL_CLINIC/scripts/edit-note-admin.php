<?php
include("database-configuration.php");

// Check if the note ID is provided in the URL parameters
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Retrieve the note details from the database
    $query = "SELECT * FROM note WHERE Note_ID=?";
    $stmt = mysqli_prepare($connection, $query);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($result)) {
        $message = $row['Note_Message'];
        $author = $row['Note_Author'];
    } else {
        // Redirect to the manage notes page if the note is not found
        header('Location: manage-notes.php');
        exit;
    }

    mysqli_stmt_close($stmt);
} else {
    // Redirect to the manage notes page if the note ID is not provided
    header('Location: manage-notes.php');
    exit;
}

// Retrieve the list of admins from the database
$query = "SELECT * FROM admin";
$adminResult = mysqli_query($connection, $query);

// Check if the form has been submitted for updating the note
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $message = $_POST['message'];
    $author = $_POST['author'];

    // Update the note in the database
    $query = "UPDATE note SET Note_Message=?, Note_Author=? WHERE Note_ID=?";
    $stmt = mysqli_prepare($connection, $query);
    mysqli_stmt_bind_param($stmt, "ssi", $message, $author, $id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header('Location: manage-notes.php');
    exit;
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/DENTAL_CLINIC/css/patient-signup.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <title>Dent-Assist | Edit Note</title>
    <link rel="icon" href="/DENTAL_CLINIC/images/logo-color.png" type="image/png">
</head>

<body>
    <section class="container">
        <header>Edit Note</header>
        <form method="post" class="form">
            <div class="column">
            </div>
            <div class="column">
                <div class="input-box">
                    <label>Note</label>
                    <input type="text" name="message" id="message" value="<?php echo $message; ?>" required>
                </div>
            </div>
            <div class="column">
                <div class="input-box">
                    <label>Admin</label>
                    <select name="author" id="author" required>
                        <option value="">Select Admin</option>
                        <?php
                        while ($row = mysqli_fetch_assoc($adminResult)) {
                            $selected = ($row['Admin_ID'] == $author) ? 'selected' : '';
                            echo "<option value='" . $row['Admin_ID'] . "' $selected>" . $row['Admin_Name'] . " " . $row['Admin_Surname'] . "</option>";
                        }
                        ?>
                    </select>
                </div>
            </div>
            </div>

            <div class="button-div">
                <button type="submit" id="update-note" name="update_note" class="button">Update Note</button>
            </div>
        </form>
    </section>
</body>

</html>
